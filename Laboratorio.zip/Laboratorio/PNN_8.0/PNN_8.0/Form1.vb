﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Val(N1.Text) < 0 Then
            PP.Text = "Negativo"
        ElseIf Val(N1.Text) = 0 Then
            PP.Text = "Nulo"
        ElseIf Val(N1.Text) > 1 Then
            PP.Text = "Positivo"
        End If
    End Sub
End Class
