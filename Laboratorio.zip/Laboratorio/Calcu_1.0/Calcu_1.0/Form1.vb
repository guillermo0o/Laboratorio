﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, As Integer
        a = TextBox1.Text
        b = TextBox2.Text
        c = TextBox3.Text

        a+b = c

    End Sub
End Class
