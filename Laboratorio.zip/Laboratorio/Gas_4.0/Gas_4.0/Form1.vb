﻿Public Class Form1
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, d, t As Integer

        a = G1.Text

        t = a * 35
        T1.Text = t

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim a, b, c, d, t As Integer

        c = D1.Text
        t = T1.Text

        d = c - t
        D2.Text = d

    End Sub
End Class
