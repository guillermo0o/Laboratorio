﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If (TextBox1.Text) <= 11 Then
            TextBox2.Text = "a.m."
        ElseIf (TextBox1.Text) >= 12 Then
            TextBox2.Text = "p.m."

        End If




    End Sub
End Class
