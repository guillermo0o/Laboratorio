﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        If Val(N1.Text) < 60 Then
            PP.Text = "Reprobado"
        ElseIf Val(N1.Text) >= 60 Then
            PP.Text = "Aprobado"
        End If
        If Val(N1.Text) >= 71 Then
            PP.Text = "Notable"
        End If
        If Val(N1.Text) >= 81 Then
            PP.Text = "Sobresaliente"
        End If
        If Val(N1.Text) >= 91 Then
            PP.Text = "Excelente"
        End If
    End Sub
End Class
