﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, d, t1, t As Integer
        a = NT1.Text
        b = NT2.Text
        c = NT3.Text
        d = NT4.Text



        t1 = a + b + c + d
        t = t1 / 4
        PR.Text = t
    End Sub
End Class
