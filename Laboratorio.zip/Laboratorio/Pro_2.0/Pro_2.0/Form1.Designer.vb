﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.NT1 = New System.Windows.Forms.TextBox()
        Me.NT2 = New System.Windows.Forms.TextBox()
        Me.NT3 = New System.Windows.Forms.TextBox()
        Me.NT4 = New System.Windows.Forms.TextBox()
        Me.PR = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(326, 74)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Promedio"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'NT1
        '
        Me.NT1.Location = New System.Drawing.Point(41, 32)
        Me.NT1.Name = "NT1"
        Me.NT1.Size = New System.Drawing.Size(100, 23)
        Me.NT1.TabIndex = 1
        Me.NT1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NT2
        '
        Me.NT2.Location = New System.Drawing.Point(41, 61)
        Me.NT2.Name = "NT2"
        Me.NT2.Size = New System.Drawing.Size(100, 23)
        Me.NT2.TabIndex = 2
        Me.NT2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NT3
        '
        Me.NT3.Location = New System.Drawing.Point(41, 90)
        Me.NT3.Name = "NT3"
        Me.NT3.Size = New System.Drawing.Size(100, 23)
        Me.NT3.TabIndex = 3
        Me.NT3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NT4
        '
        Me.NT4.Location = New System.Drawing.Point(41, 119)
        Me.NT4.Name = "NT4"
        Me.NT4.Size = New System.Drawing.Size(100, 23)
        Me.NT4.TabIndex = 4
        Me.NT4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PR
        '
        Me.PR.Location = New System.Drawing.Point(326, 103)
        Me.PR.Name = "PR"
        Me.PR.Size = New System.Drawing.Size(100, 23)
        Me.PR.TabIndex = 5
        Me.PR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(463, 219)
        Me.Controls.Add(Me.PR)
        Me.Controls.Add(Me.NT4)
        Me.Controls.Add(Me.NT3)
        Me.Controls.Add(Me.NT2)
        Me.Controls.Add(Me.NT1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents NT1 As TextBox
    Friend WithEvents NT2 As TextBox
    Friend WithEvents NT3 As TextBox
    Friend WithEvents NT4 As TextBox
    Friend WithEvents PR As TextBox
End Class
